---
layout:     post
title:      Open Github Pages for blogs
subtitle:   Others
date:       2018-09-24
author:     Clendy
catalog: true
tags:
    - git
    - Markdown
---

# Organization
_config.yml ：全局配置文件

posts :放文章的文件夹

img 存放图片的文件夹

# Settings (mainly on _config.yml)

# Sidebar settings
sidebar: true

sidebar-about-description: 

sidebar-avatar: 


# Reference

*[BY Blogs](https://www.jianshu.com/p/e68fba58f75c)

*[xudailong Blogs](https://blog.csdn.net/xudailong_blog/article/details/78762262)

*[jekyll](https://www.jekyll.com.cn/)

*[gitalk](http://qiubaiying.top/2017/12/19/%E4%B8%BA%E5%8D%9A%E5%AE%A2%E6%B7%BB%E5%8A%A0-Gitalk-%E8%AF%84%E8%AE%BA%E6%8F%92%E4%BB%B6/)
